from django.shortcuts import render,get_object_or_404
from django.http import HttpResponse,HttpResponseRedirect
from django.http import JsonResponse
from django.urls import reverse
from myapp.models import Employee
from myapp.utilities import sendmail,token_request,tokens
from random import randint
from rest_framework.utils import json

def indexPage(request):
    return render(request,"index.html")


def RegisterEmployee(request):
    name=request.POST['name']
    contact=request.POST['contact']
    username=request.POST['username']
    email=request.POST['email']
    password=request.POST['password']
    birthday=request.POST['birthday']
    emp=Employee(name=name, contact=contact, username=username, email=email, password=password, birthday=birthday)
    emp.save()
    otp=randint(100000,999999)
    sendmail('Django','mail_template',email,{'name':name,'otp':otp})
    print(emp.id,' ',otp)
    return render(request,"otp.html",{'id':emp.id,'otp':otp})

def loginpage(request):
    return render(request,"login.html")

def checkotp(request):
    otp=request.POST['otp']
    uotp=request.POST['uotp']    
    if otp==uotp:
        return render(request,"login.html",{'msg2':'Account Created. Login to Continue'})
    else:
        id=request.POST['id']
        stu=get_object_or_404(Employee,pk=id)
        stu.delete()
        return render(request,"index.html",{'msg':'Invalid OTP. Register Again'})

def fetchall(request):
    emp=Employee.objects.all()
    return render(request,"viewall.html",{'emp':emp})

def deleterecord(request,pk):
    stu=get_object_or_404(Employee,pk=pk)
    stu.delete()
    return HttpResponseRedirect(reverse('fetch'))

def updaterecord(request,pk):
    stu=get_object_or_404(Employee,pk=pk)
    return render(request,"update.html",{'stu':stu})

def editdata(request):
    id=request.POST['id']
    name=request.POST['name']
    contact=request.POST['contact']
    username=request.POST['username']
    email=request.POST['email']
    password=request.POST['password']
    birthday=request.POST['birthday']
    emp=Employee(id=id, name=name, contact=contact, username=username, email=email, password=password, birthday=birthday)
    emp.save()
    return HttpResponseRedirect(reverse('fetch'))

def validdata(request):
    data = json.loads(request.body)
    if request.type=='POST':
        email=data['email']
        password=data['password']
        emp=Employee.objects.filter(email=email,password=password)
        if emp:
            authToken=token_request(emp.id)
            response={'statusCode':200,'message':'All OK!','authToken':authToken}
        else:
            response={'statusCode':404,'message':'Check email or password'}
    else:
        response={'statusCode':400,'message':'Data not recieved'}
    return JsonResponse({'response':response})
        
def getprofile(request):
    if request.type=='POST':
        authToken=request.data['authToken']
        emp=Employee.objects.filter(id=tokens[authToken])
        if emp:
            response={'statusCode':200,'message':'All OK!','date':{'name':emp.name,'contact':emp.contact,'email':emp.email,'username':emp.username,'birthday':emp.birthday}}
        else:
            response={'statusCode':404,'message':'Invalid authToken'}
    else:
        response={'statusCode':400,'message':'Data not recieved'}
    return JsonResponse({'response':response})